#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np
from flask import Flask, request, jsonify
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

# 导入你的服务类型
from vlm_noetic_bridge.srv import QueryVLM, QueryVLMRequest, QueryVLMResponse

# --- Flask App 初始化 ---
app = Flask(__name__)

# --- ROS 初始化 ---
# 初始化一个节点
rospy.init_node('vlm_web_bridge', anonymous=True)
# 创建CvBridge实例
bridge = CvBridge()

# 等待并创建ROS服务客户端
rospy.loginfo("WEB_SERVER: Waiting for /query_vlm_task service...")
rospy.wait_for_service('/query_vlm_task')
vlm_service_client = rospy.ServiceProxy('/query_vlm_task', QueryVLM)
rospy.loginfo("WEB_SERVER: Connected to /query_vlm_task service.")


# --- Web API 端点 ---
@app.route('/query', methods=['POST'])
def query_vlm():
    # 检查请求中是否包含文件
    if 'image' not in request.files:
        return jsonify({'error': 'No image file provided'}), 400
    
    file = request.files['image']
    
    # 将文件内容读取为numpy数组，然后解码为OpenCV图像
    np_arr = np.fromstring(file.read(), np.uint8)
    cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if cv_image is None:
        return jsonify({'error': 'Could not decode image'}), 400

    try:
        # 将OpenCV图像转换为ROS Image消息
        ros_image_msg = bridge.cv2_to_imgmsg(cv_image, "bgr8")
        
        # 创建ROS服务请求
        ros_request = QueryVLMRequest()
        ros_request.image = ros_image_msg

        # 调用ROS服务
        rospy.loginfo("WEB_SERVER: Calling VLM service via HTTP request...")
        ros_response = vlm_service_client(ros_request)
        
        # 将ROS服务响应封装成JSON返回
        return jsonify({
            'success': True,
            'task': ros_response.task_name
        })

    except Exception as e:
        rospy.logerr(f"WEB_SERVER: An error occurred: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # 启动Flask服务器
    # host='0.0.0.0' 让服务器可以从外部访问
    app.run(host='0.0.0.0', port=5000)
