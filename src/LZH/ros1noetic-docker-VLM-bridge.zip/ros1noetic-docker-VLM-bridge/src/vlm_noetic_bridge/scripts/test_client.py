#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import sys
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

# 导入你创建的服务类型
from vlm_noetic_bridge.srv import QueryVLM, QueryVLMRequest

def call_vlm_service(image_path):
    # 1. 等待服务可用
    # 这会一直阻塞，直到名为 '/query_vlm_task' 的服务启动
    rospy.loginfo("Waiting for /query_vlm_task service...")
    rospy.wait_for_service('/query_vlm_task')
    rospy.loginfo("Service is available.")

    try:
        # 2. 创建一个服务的句柄（或称为代理）
        vlm_service_client = rospy.ServiceProxy('/query_vlm_task', QueryVLM)

        # 3. 使用OpenCV从文件加载一张图片
        rospy.loginfo(f"Loading image from: {image_path}")
        cv_image = cv2.imread(image_path)
        if cv_image is None:
            rospy.logerr(f"Failed to load image from {image_path}. Make sure the path is correct.")
            return

        # 4. 使用CvBridge将OpenCV图像转换为ROS Image消息
        bridge = CvBridge()
        try:
            ros_image_msg = bridge.cv2_to_imgmsg(cv_image, "bgr8")
        except Exception as e:
            rospy.logerr(f"CvBridge Error: {e}")
            return

        # 5. 创建一个服务的请求对象
        request = QueryVLMRequest()
        # 将ROS图像消息放入请求中
        request.image = ros_image_msg

        # 6. 调用服务并等待响应
        rospy.loginfo("Calling service with the image...")
        response = vlm_service_client(request)

        # 7. 打印服务返回的结果
        rospy.loginfo(f"Service responded with task: '{response.task_name}'")
        return response.task_name

    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

if __name__ == '__main__':
    # 检查是否提供了图片路径作为参数
    if len(sys.argv) < 2:
        print("Usage: rosrun vlm_noetic_bridge test_client.py <path_to_image>")
        sys.exit(1)

    image_file_path = sys.argv[1]
    
    try:
        # 初始化一个节点（对于客户端来说，它可以是匿名的）
        rospy.init_node('vlm_service_test_client')
        call_vlm_service(image_file_path)

    except rospy.ROSInterruptException:
        pass