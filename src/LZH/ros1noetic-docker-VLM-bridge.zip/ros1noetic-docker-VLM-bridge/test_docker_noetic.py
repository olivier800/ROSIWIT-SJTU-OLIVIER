import requests
import sys

API_URL = "http://0.0.0.0:5000/query"

def call_vlm_via_web(image_path):
    try:
        with open(image_path, 'rb') as f:
            files = {'image':(image_path, f, 'image/png')}
            response = requests.post(API_URL, files=files)
            response.raise_for_status()

            result = response.json()
            if result.get('success'):
                print(f"VLM Result Task: {result.get('task')}")
            else:
                print(f"Error from server: {result.get('error')}")
    
    except requests.exceptions.RequestException as e:
        print(f"HTTP Request failed:{e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: Pyhton3 host_web_client.py")
        sys.exit(1)
    call_vlm_via_web(sys.argv[1])

